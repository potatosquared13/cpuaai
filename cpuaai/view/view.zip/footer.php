
<div class="text-center mt-1" style="margin-bottom:0;background-color:#030A28;color:white;">
  
  <b>CENTRAL PHILIPPINE UNIVERSITY © 2019. All Rights Reserved.</b>
  
</div>