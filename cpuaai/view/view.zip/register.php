<div class="container-fluid mt-2 mb-2">

  <div class="row">
   
	<div class="col-sm-12">
		
		<div class="panel panel-default">
				<div class="panel-heading mb-0 text-center" style="background-color:black;font-size:22px;color:white;">
					Create New Account
				</div>
				
				<div class="panel-body mt-0 " style="background-color:#030A28;font-size:22px;color:white;">

				
					<fieldset >
					<form role="form"  method="post" action="index.php?command=2">
						<div class="row" style="background-color:#030A28;font-size:22px;color:white;">
							<div class="col-sm-3  col-md-offset-1" style="background-color:#030A28;font-size:22px;color:white;">
							
							

								<div class="form-group">
								<span class="input-group-addon">
											<i class="glyphicon glyphicon-user">Firstname</i>
										</span> 
									<div class="input-group">
									
										<input style="border:5px solid;border-color:black;" class="form-control text-center" placeholder="First Name" name="firstname" type="text" autofocus>
									</div>
								</div>
								
								<div class="form-group">
								<span class="input-group-addon">
											<i class="glyphicon glyphicon-user">Middlename</i>
										</span> 
									<div class="input-group">
										
										<input style="border:5px solid;border-color:black;" class="form-control text-center" placeholder="Middle Name" name="middlename" type="text" autofocus>
									</div>
								</div>


								<div class="form-group">
								<span class="input-group-addon">
											<i class="glyphicon glyphicon-user">Lastname</i>
										</span> 
									<div class="input-group">
										
										<input style="border:5px solid;border-color:black;" class="form-control text-center" placeholder="Last Name" name="lastname" type="text" autofocus>
									</div>
								</div>
								
								<div class="form-group">
								<span class="input-group-addon">
											<i class="glyphicon glyphicon-user">Gender</i>
										</span>
									<div class="input-group">
										 
										<select name="sex" size="1" class="form-control text-center" >
											<option value=""></option>
											<option value="Male">Male</option>
											<option value="Female">Female</option>
										</select>									
									</div>
								</div>


								
							</div>
							
							<div class="col-sm-3  col-md-offset-1" style="background-color:#030A28;font-size:22px;color:white;">

							<div class="form-group">
							<span class="input-group-addon">
											<i class="glyphicon glyphicon-user">Address</i>
										</span> 
									<div class="input-group">
										
										<input style="border:5px solid;border-color:black;" class="form-control text-center" placeholder="Address" name="address" type="text" autofocus>
									</div>
								</div>

								<div class="form-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-user">College</i>
										</span> 
									<div class="input-group">
									
									<?php
										$result3 = $this->model->getcollege();
										echo "<select name='college' size='1' class='form-control'>";
            							foreach($result3 as $title=>$getcollege){
											echo "<option value='$getcollege->college'>$getcollege->college</option>";	
										} 
										echo "</select>";
									?>									
										
									</div>
								</div>



								<div class="form-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-user">Course</i>
										</span> 
									<div class="input-group">
									
									<?php
										$result2 = $this->model->getcourse();
										echo "<select name='course' size='1' class='form-control'>";
            							foreach($result2 as $title=>$getcourse){
											echo "<option value='$getcourse->course'>$getcourse->course_title</option>";	
										} 
										echo "</select>";
									?>									
										
									</div>
								</div>

								<div class="form-group">
										<span class="input-group-addon">
											<i class="glyphicon glyphicon-user">Year Graduated</i>
										</span> 
									<div class="input-group">
									
									<?php
										$result = $this->model->getyeargraduated();
										echo "<select name='yeargraduated' size='1' class='form-control'>";
            							foreach($result as $title=>$getyeargraduated){
											echo "<option value='$getyeargraduated->year_graduated'>$getyeargraduated->year_graduated</option>";	
										} 
										echo "</select>";
									?>									
										
									</div>
								</div>


								

								
								</div>
								<div class="col-sm-3  col-md-offset-1" style="background-color:#030A28;font-size:22px;color:white;">

								<div class="form-group">
								<span class="input-group-addon">
											<i class="glyphicon glyphicon-lock">Email Address</i>
										</span>
									<div class="input-group">
										
										<input style="border:5px solid;border-color:black;" class="form-control text-center" placeholder="Email Address" name="email" type="text">
									</div>
								</div>
								

								<div class="form-group">
								<span class="input-group-addon">
											<i class="glyphicon glyphicon-lock">Contact Number</i>
										</span>
									<div class="input-group">
										
										<input style="border:5px solid;border-color:black;" class="form-control text-center" placeholder="Contact Number" name="contact" type="text">
									</div>
								</div>

								<div class="form-group">
								<span class="input-group-addon">
											<i class="glyphicon glyphicon-lock">Social Media Account</i>
										</span>
									<div class="input-group">
										
										<input style="border:5px solid;border-color:black;" class="form-control text-center" placeholder="Social Media Account" name="social" type="text">
									</div>
								</div>

								

								</div>
								<div class="col-sm-3  col-md-offset-1" style="background-color:#030A28;font-size:22px;color:white;">

								<div class="form-group">
								<span class="input-group-addon">
											<i class="glyphicon glyphicon-user">Username</i>
										</span> 
									<div class="input-group">
										
										<input style="border:5px solid;border-color:black;" class="form-control text-center" placeholder="User Name" name="username" type="text" autofocus>
									</div>
								</div>	


								<div class="form-group">
								<span class="input-group-addon">
											<i class="glyphicon glyphicon-lock">Password</i>
										</span>
									<div class="input-group">
										
										<input style="border:5px solid;border-color:black;" class="form-control text-center" placeholder="Password" name="password" type="password">
									</div>
								</div>
		
								<input style="border:5px solid;border-color:black;" class="form-control text-center"  name="role" type="hidden" value="User">

									<div class="form-group">
									<input type="hidden" class="btn btn-lg btn-primary btn-block" name="register" value=1>
								</div>
								<div class="form-group">
									<input type="submit" class="btn btn-lg btn-primary btn-block" value="Register">
								</div>
								</form>
								<a class="btn btn-lg btn-primary btn-block" href="index.php?command=0">Back to Login</a>	

								
								
							</div>
							</div>
							</fieldset>
						

							











						</div>
					
			</div>





	</div>
	

  </div>
</div>

